import sys

__all__ = ['QtCore', 'QtGui', 'QtNetwork', 'QtSql', 'QtSvg', 'QtTest', 'QtWebKit', 'QtScript']

if sys.version_info[0] < 3:
    import private

__version__         = "1.0.8"
__version_info__    = (1, 0, 8, "final", 1)
